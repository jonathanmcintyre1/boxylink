<?php defined('ALTUMCODE') || die() ?>

<div data-biolink-block-id="<?= $data->link->biolink_block_id ?>" class="col-12 my-2">
    <div class="link-iframe-round">
        <blockquote class="link-round" data-video-id="<?= $data->embed ?>">
            <section></section>
        </blockquote>

        <script defer src="https://www.tiktok.com/embed.js"></script>
    </div>
</div>
